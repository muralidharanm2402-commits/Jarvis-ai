package com.jarvis.ultimate

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null
    private var tamil = true
    private var torchOn = false
    private var cameraId: String? = null
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val cyan = 0xFF59E8FF.toInt()
    private val muted = 0xFF91AFC0.toInt()
    private val dark = 0xFF06111D.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF030A12.toInt()
        window.navigationBarColor = 0xFF030A12.toInt()
        tts = TextToSpeech(this, this)
        buildScreen()
        addMessage("JARVIS", "வணக்கம்! I am JARVIS. Tap the microphone or type a command.")
        updateDeviceInfo()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 14)
            setBackgroundColor(dark)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "◉  J.A.R.V.I.S\n     PERSONAL AI SYSTEM"
            setTextColor(cyan); textSize = 17f
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = button("AI SETUP") { configureAiEndpoint() }
        header.addView(settings)
        root.addView(header)

        val orb = TextView(this).apply {
            text = "\n        ◉\n     J A R V I S\n"
            textSize = 25f; gravity = Gravity.CENTER; setTextColor(cyan)
            setPadding(0, 30, 0, 8)
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, 175))
        status = TextView(this).apply {
            text = "● SYSTEM ONLINE"; setTextColor(0xFF56F5B0.toInt())
            textSize = 11f; gravity = Gravity.CENTER
        }
        root.addView(status)

        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val langRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        langRow.addView(button("தமிழ்") { tamil = true; addMessage("SYSTEM", "Tamil voice selected.") })
        langRow.addView(button("ENGLISH") { tamil = false; addMessage("SYSTEM", "English voice selected.") })
        root.addView(langRow)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Type a command / கேள்வி..."
            setHintTextColor(muted); setTextColor(-1); textSize = 15f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setBackgroundColor(0xFF10283A.toInt())
            setPadding(14, 10, 14, 10)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendText(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, 52, 1f))
        row.addView(button("SEND") { sendText() })
        root.addView(row)

        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("🎙 TALK") { startListening() })
        actions.addView(button("FLASH") { toggleFlash() })
        actions.addView(button("DEVICE") { updateDeviceInfo() })
        root.addView(actions)
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 11f; setTextColor(cyan)
            setBackgroundColor(0xFF10283A.toInt())
            setOnClickListener { action() }
        }

    private fun addMessage(who: String, text: String) {
        val tv = TextView(this).apply {
            this.text = "$who\n$text"
            setTextColor(if (who == "YOU") 0xFFB9D8FF.toInt() else cyan)
            textSize = 14f
            setPadding(13, 11, 13, 11)
            setBackgroundColor(if (who == "YOU") 0xFF0A2037.toInt() else 0xFF0A1B29.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 5)
        chat.addView(tv, lp)
    }

    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handleCommand(text)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Speech recognition is not available on this device. Please type your message.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (tamil) "ta-IN" else "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (tamil) "ta-IN" else "en-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (tamil) "JARVIS கேட்கிறது..." else "JARVIS is listening...")
            }
            speech?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "● LISTENING" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "● PROCESSING" }
                override fun onError(error: Int) { status.text = "● SYSTEM ONLINE" }
                override fun onResults(results: Bundle?) {
                    status.text = "● SYSTEM ONLINE"
                    val result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!result.isNullOrBlank()) handleCommand(result)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speech?.startListening(intent)
        } catch (e: Exception) {
            respond("Voice input could not start: ${e.localizedMessage}")
        }
    }

    private fun handleCommand(raw: String) {
        addMessage("YOU", raw)
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("time") || q.contains("மணி") || q.contains("நேரம்") ->
                respond("The time is ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())}")
            q.contains("date") || q.contains("today") || q.contains("தேதி") ->
                respond("Today is ${java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(java.util.Date())}")
            q.contains("battery") || q.contains("பேட்டரி") -> updateDeviceInfo()
            q.contains("flash") || q.contains("torch") || q.contains("டார்ச்") -> toggleFlash()
            q.contains("open youtube") || q.contains("youtube திற") -> openApp("com.google.android.youtube")
            q.contains("open whatsapp") || q.contains("whatsapp திற") -> openApp("com.whatsapp")
            q.contains("open chrome") || q.contains("chrome திற") -> openApp("com.android.chrome")
            q.contains("open settings") || q.contains("settings திற") ->
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            q.contains("help") || q.contains("என்ன செய்ய") ->
                respond("I can tell time/date, check battery, toggle flashlight, open YouTube/WhatsApp/Chrome/Settings, and answer through your configured AI server. More integrations will be added.")
            else -> askAi(raw)
        }
    }

    private fun respond(text: String) {
        addMessage("JARVIS", text)
        if (::tts.isInitialized) {
            val utterance = if (tamil) Locale("ta", "IN") else Locale("en", "IN")
            tts.language = utterance
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    private fun openApp(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else respond("That app is not installed on this phone.")
    }

    private fun updateDeviceInfo() {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        addMessage("JARVIS DEVICE", "Battery: $percent%  |  Android: ${android.os.Build.VERSION.RELEASE}  |  Device: ${android.os.Build.MODEL}")
    }

    private fun toggleFlash() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 11)
            return
        }
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            if (cameraId == null) cameraId = manager.cameraIdList.firstOrNull()
            val id = cameraId ?: run { respond("No flashlight was found."); return }
            torchOn = !torchOn
            manager.setTorchMode(id, torchOn)
            respond(if (torchOn) "Flashlight turned on." else "Flashlight turned off.")
        } catch (e: Exception) { respond("Flashlight control failed: ${e.localizedMessage}") }
    }

    private fun configureAiEndpoint() {
        val field = EditText(this).apply {
            hint = "https://your-worker.example.workers.dev/chat"
            setText(prefs.getString("endpoint", ""))
            setTextColor(-1); setHintTextColor(muted)
        }
        val tokenField = EditText(this).apply {
            hint = "JARVIS gateway token"
            setText(prefs.getString("gateway_token", ""))
            setTextColor(-1); setHintTextColor(muted)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0)
            addView(field)
            addView(tokenField)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Connect JARVIS Cloud AI")
            .setMessage("Enter your HTTPS Cloudflare Worker / backend URL and gateway token. Never enter your OpenAI API key in this app.")
            .setView(box)
            .setPositiveButton("SAVE") { _, _ ->
                val endpoint = field.text.toString().trim()
                val gatewayToken = tokenField.text.toString().trim()
                if (endpoint.startsWith("https://") && gatewayToken.isNotBlank()) {
                    prefs.edit().putString("endpoint", endpoint).putString("gateway_token", gatewayToken).apply()
                    respond("Cloud AI connection settings saved. Ask me anything!")
                } else respond("Please enter a valid HTTPS URL and gateway token.")
            }
            .setNegativeButton("CANCEL", null).show()
    }

    private fun askAi(message: String) {
        val endpoint = prefs.getString("endpoint", "") ?: ""
        if (endpoint.isBlank()) {
            respond("My AI brain is not connected yet. Tap AI SETUP and enter your secure HTTPS backend URL. Local phone commands are available now.")
            return
        }
        status.text = "● THINKING"
        thread {
            var answer: String
            try {
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("X-Jarvis-Token", prefs.getString("gateway_token", "") ?: "")
                }
                val body = JSONObject().put("message", message)
                    .put("language", if (tamil) "ta-IN" else "en-IN").toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                connection.disconnect()
                answer = if (code in 200..299) JSONObject(response).optString("reply", "The AI server returned no reply.")
                          else "AI server error ($code). Please check your backend."
            } catch (e: Exception) {
                answer = "I could not reach the AI server. Check your internet and backend URL."
            }
            runOnUiThread { status.text = "● SYSTEM ONLINE"; respond(answer) }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("en", "IN")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == 10) startListening()
            if (requestCode == 11) toggleFlash()
        } else respond("Permission denied. You can enable it later in Android app settings.")
    }

    override fun onDestroy() {
        speech?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
