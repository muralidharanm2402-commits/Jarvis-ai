# JARVIS Cloud AI Backend (Cloudflare Workers)

இந்த backend-ல் OpenAI API key server secret ஆக இருக்கும். Android APK-க்குள் API key சேர்க்கப்படாது.

## Phone-லிருந்து deploy செய்வது
1. Cloudflare account உருவாக்கி Dashboard-ல் Workers & Pages திறக்கவும்.
2. Create application → Create Worker → Deploy.
3. Worker editor-ல் `worker.js` உள்ள code-ஐ முழுவதும் paste செய்து Save and Deploy செய்யவும்.
4. Worker Settings → Variables and Secrets பகுதியில் கீழே உள்ள secrets சேர்க்கவும்:
   - `OPENAI_API_KEY` = உங்களுடைய OpenAI API key (Secret)
   - `JARVIS_GATEWAY_TOKEN` = நீங்களே உருவாக்கும் நீளமான random token (Secret)
   - `OPENAI_MODEL` = `gpt-6-astra` (தேவைப்பட்டால் உங்கள் API project-ல் கிடைக்கும் model ID-க்கு மாற்றவும்; இதை Text variable ஆக அமைக்கலாம்)
5. Worker URL-ஐ copy செய்யவும்; முடிவில் `/` மட்டும் இருந்தால் அதற்கு `/` + `chat` சேர்க்கவும். உதாரணம்: `https://your-worker.workers.dev/chat`.
6. APK-ல் AI SETUP திறந்து Worker URL மற்றும் அதே `JARVIS_GATEWAY_TOKEN` value-ஐ paste செய்து Save செய்யவும்.
7. Tamil / English தேர்வு செய்து கேள்வி கேளுங்கள்.

## முக்கிய பாதுகாப்பு
- OpenAI API key-ஐ Android app, GitHub repo, screenshot அல்லது chat-ல் paste செய்ய வேண்டாம். Cloudflare Secret-ல் மட்டும் வைக்கவும்.
- Gateway token-ஐ யாரிடமும் பகிர வேண்டாம். வெளியானால் Cloudflare-ல் அதை மாற்றி app-ல் புதிய token save செய்யவும்.
- OpenAI API usage-க்கு தனி billing/credits தேவைப்படலாம்.
- `gpt-6-astra` உங்கள் API account-ல் கிடைக்கவில்லை என்றால், API dashboard-ல் கிடைக்கும் model ID-ஐ `OPENAI_MODEL`-ல் அமைக்கவும்.
