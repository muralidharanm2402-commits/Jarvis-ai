export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, X-Jarvis-Token",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return json({ error: "Use POST" }, 405, cors);
    if (!env.OPENAI_API_KEY || !env.JARVIS_GATEWAY_TOKEN) {
      return json({ error: "Server secrets are not configured" }, 500, cors);
    }
    if (request.headers.get("X-Jarvis-Token") !== env.JARVIS_GATEWAY_TOKEN) {
      return json({ error: "Unauthorized" }, 401, cors);
    }

    let body;
    try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400, cors); }
    const message = String(body.message || "").trim();
    const language = String(body.language || "en-IN");
    if (!message) return json({ error: "Message is required" }, 400, cors);
    if (message.length > 8000) return json({ error: "Message too long" }, 413, cors);

    const languageRule = language.startsWith("ta")
      ? "Reply naturally in Tamil. You may retain common technical words in English."
      : "Reply naturally in English.";
    const instructions = `You are JARVIS, a capable, respectful personal AI assistant for an Android user in India. ${languageRule} Be accurate, concise, and practical. Do not claim you performed phone actions unless the app confirms them. If a task needs permissions or an external service, explain that clearly.`;

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: env.OPENAI_MODEL || "gpt-6-astra",
        instructions,
        input: message,
        max_output_tokens: 900,
      }),
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return json({ error: data.error?.message || `AI provider error (${upstream.status})` }, 502, cors);
    }
    const reply = (data.output || [])
      .filter(item => item.type === "message")
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text || "")
      .join("\n").trim();
    return json({ reply: reply || "I could not generate a response. Please try again." }, 200, cors);
  }
};

function json(value, status, headers = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...headers },
  });
}
