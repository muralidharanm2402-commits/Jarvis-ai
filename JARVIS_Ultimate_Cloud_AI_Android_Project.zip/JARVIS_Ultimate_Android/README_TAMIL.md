# JARVIS Ultimate – Cloud AI Android APK

இந்த native Android project-ல் Tamil/English voice input, Text-to-Speech, chat UI, time/date, battery/device info, flashlight, app shortcuts, மற்றும் Cloud AI backend connection உள்ளன.

## முதலில் செய்ய வேண்டியது
1. `cloud-backend/README_TAMIL.md` வழிமுறையைப் பின்பற்றி Cloudflare Worker deploy செய்யவும்.
2. OpenAI API key மற்றும் நீங்களே உருவாக்கும் gateway token-ஐ Cloudflare Worker Secrets-ல் மட்டும் அமைக்கவும்.
3. Android app install ஆனபின் AI SETUP-ல் Worker HTTPS URL + gateway token அமைக்கவும்.

## Android phone-ல் APK build
1. இந்த ZIP-ஐ download செய்து Extract செய்யவும்.
2. GitHub-ல் sign in செய்து `jarvis-ultimate` என்ற புதிய repository உருவாக்கவும்.
3. Extract செய்த project உள்ளடக்கங்கள் அனைத்தையும் repository root-க்கு upload செய்யவும். `.github/workflows/build-apk.yml`-ஐ தவறாமல் சேர்க்கவும்.
4. GitHub repository → Actions → `Build JARVIS APK` → Run workflow.
5. Build முடிந்ததும் run-ஐத் திறந்து `JARVIS-Ultimate-debug-APK` artifact download செய்யவும்.
6. Artifact ZIP extract செய்து `app-debug.apk` install செய்யவும். Android-ல் தேவையானால் browser/file manager-க்கு Install unknown apps அனுமதி கொடுக்கவும்.

## தற்போதைய வரம்புகள்
இது install செய்யக்கூடிய debug APK உருவாக்கும் source project; இந்த சூழலில் Android SDK/Gradle build கிடைக்காததால் APK binary-ஐ இங்கே compile செய்து தர முடியவில்லை. Cloud AI பயன்படுத்த internet மற்றும் API billing/credits தேவைப்படலாம். Always-on wake word, background listening, full device control, SMS/call automation ஆகியவை இன்னும் சேர்க்கப்படவில்லை. Android permissions மற்றும் phone model அடிப்படையில் சில அம்சங்கள் மாறலாம்.
